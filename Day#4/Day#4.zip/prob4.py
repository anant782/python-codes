string = "Python is easy and Python is powerful"
first_index = string.find("Python")
last_index = string.rfind("Python")
print("First Index:",first_index)
print("Last Index:", last_index)