letter = '''\"Python\" \n\tis\n\t awesome'''
print(letter)