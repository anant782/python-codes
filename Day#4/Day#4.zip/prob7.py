user_input= input("Enter Any Thing Name:")

middle = len(user_input) // 2
print(user_input[middle])