user_input = input("Enter Any Sentence:")
replacement = user_input.replace("  ", " ")
print(replacement)