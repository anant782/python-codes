user_input= input("Write Anything I will write first 3 letter and last 3 letter:")
first3 = user_input[0:3]
last3 = user_input[-3:]
print("Here Is The First 3 Letter:",first3)
print("Here Is The Last 3 Letter:",last3)