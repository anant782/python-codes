user_input = input("I can Write Ur sentence Length and write reverse:")
len1 = len(user_input)
reverse = user_input[::-1]
print("Here Is Ur Length Of sentence:", len1)
print("Here Is The reverse Of ur Sentence:", reverse)